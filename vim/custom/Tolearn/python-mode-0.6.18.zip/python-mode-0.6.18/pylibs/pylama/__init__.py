" pylama -- Python code audit. "

version_info = (0, 3, 2)

__version__ = version = '.'.join(map(str, version_info))
__project__ = __name__
__author__ = "Kirill Klenov <horneds@gmail.com>"
__license__ = "GNU LGPL"
